/*
 *@Type Command.java
 * @Desc
 * @Author urmsone urmsone@163.com
 * @date 2024/6/13 01:50
 * @version
 */
package model.command;

public interface Command {
    String getKey();
}
